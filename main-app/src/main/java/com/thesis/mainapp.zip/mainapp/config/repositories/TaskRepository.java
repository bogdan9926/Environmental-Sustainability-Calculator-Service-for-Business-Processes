package com.thesis.mainapp.config.repositories;

import com.thesis.mainapp.domain.Process;
import com.thesis.mainapp.domain.Task;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TaskRepository extends JpaRepository<Task, Long> {
    public Task findByNameAndProcess(String name, Process process);
}
