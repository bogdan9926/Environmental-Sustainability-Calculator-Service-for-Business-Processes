import React, { useState } from 'react';
import Modal from 'react-modal';
import './emissionFactorEditor.css';

Modal.setAppElement('#root');

const EmissionFactorEditor = ({ emissionFactors, setEmissionFactors, onSubmit }) => {
    const [selectedEmissionFactor, setSelectedEmissionFactor] = useState(null);
    const [modalIsOpen, setModalIsOpen] = useState(false);

    const openModal = (index) => {
        setSelectedEmissionFactor(index);
        setModalIsOpen(true);
    };

    const closeModal = () => {
        setSelectedEmissionFactor(null);
        setModalIsOpen(false);
    };

    const handleEmissionFactorSubmit = async () => {
        if (selectedEmissionFactor !== null) {
            const updatedEmissionFactor = emissionFactors[selectedEmissionFactor];
            await onSubmit(updatedEmissionFactor);
            closeModal();
        }
    };

    const handleEmissionFactorChange = (e) => {
        const { name, value } = e.target;
        if (selectedEmissionFactor !== null) {
            const updatedEmissionFactors = [...emissionFactors];
            updatedEmissionFactors[selectedEmissionFactor][name] = value;
            setEmissionFactors(updatedEmissionFactors);
        }
    };

    return (
        <div className="annotation-editor">
            <button onClick={() => openModal(0)} className="edit-annotations-btn">Edit Emission Factors</button>
            <Modal
                className="modal"
                isOpen={modalIsOpen}
                onRequestClose={closeModal}
                contentLabel="Edit Emission Factor"
            >
                {selectedEmissionFactor !== null && emissionFactors.length > 0 && (
                    <>
                        <h3>Edit Emission Factor</h3>
                        <div className="tabs">
                            {emissionFactors.map((emission, index) => (
                                <button
                                    key={index}
                                    onClick={() => setSelectedEmissionFactor(index)}
                                    className={selectedEmissionFactor === index ? 'active' : ''}
                                >
                                    {emission.fuelType}
                                </button>
                            ))}
                        </div>
                        <div className="input-group">
                            <label>Unit:</label>
                            <input
                                type="text"
                                name="unit"
                                value={emissionFactors[selectedEmissionFactor].unit}
                                onChange={handleEmissionFactorChange}
                            />
                        </div>
                        <div className="input-group">
                            <label>Factor:</label>
                            <input
                                type="number"
                                name="factor"
                                value={emissionFactors[selectedEmissionFactor].factor}
                                onChange={handleEmissionFactorChange}
                            />
                        </div>
                        <button className="submit-button" onClick={handleEmissionFactorSubmit}>Submit</button>
                        <button className="close-button" onClick={closeModal}>Close</button>
                    </>
                )}
                {selectedEmissionFactor !== null && emissionFactors.length === 0 && (
                    <div className="annotation-editor-modal">
                        <h3>No Emission Factors Available</h3>
                        <button className="close-button" onClick={closeModal}>Close</button>
                    </div>
                )}
            </Modal>
        </div>
    );
};

export default EmissionFactorEditor;
