package com.thesis.mainapp.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.thesis.mainapp.config.repositories.*;
import com.thesis.mainapp.config.TimeUnitConverter;
import com.thesis.mainapp.domain.FrontendData;
import com.thesis.mainapp.domain.FuelEmissionFactor;
import com.thesis.mainapp.domain.Task;
import com.thesis.mainapp.domain.annotations.ResourceAnnotation;
import com.thesis.mainapp.domain.intermediate.IntermediateCo2Emission;
import com.thesis.mainapp.domain.intermediate.IntermediateProcessConsumption;
import com.thesis.mainapp.domain.Process;
import com.thesis.mainapp.domain.annotations.ResourceUsage;
import com.thesis.mainapp.domain.annotations.TaskAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class EmissionFactorService {
    @Autowired
    private ProcessRepository processRepository;

    @Autowired
    private ResourceAnnotationRepository resourceAnnotationRepository;

    @Autowired
    private IntermediateProcessConsumptionRepository intermediateProcessConsumptionRepository;

    @Autowired
    private FuelEmissionFactorRepository fuelEmissionFactorRepository;
    @Autowired
    private IntermediateCo2EmissionRepository intermediateCo2EmissionRepository;
    @Autowired
    private WebSocketService webSocketService;
    @Autowired
    private TaskRepository taskRepository;
    @Transactional
    public List<IntermediateProcessConsumption> calculateConsumption(Map map, TaskAnnotation taskAnnotation) {
//        String activityId = map.get("jobId").toString();
        List<IntermediateProcessConsumption> intermediateProcessConsumptionList = new ArrayList<>();
        List<ResourceUsage> resourceUsagesList = taskAnnotation.getResourcesUsed();
        for (ResourceUsage resourceUsage : resourceUsagesList) {
            ResourceAnnotation resource = resourceAnnotationRepository.findByNameAndProcess(resourceUsage.getResourceName(), taskAnnotation.getProcess());
            if (resource.getType().equals(ResourceAnnotation.ATOMIC)) {
                Process process = processRepository.findByProcessNameAndProcessKey(map.get("processName").toString(), map.get("processKey").toString());

                String fromUnit = resourceUsage.getUnit();
                String toUnit = resource.getTimeUnit();
                double resourceUsageValue;
                if (resourceUsage.getTimeUsed() != null)
                    resourceUsageValue = Double.parseDouble(resourceUsage.getTimeUsed());
                else {
                    Task task = taskRepository.findByNameAndProcess(map.get("taskName").toString(),process);
                    LocalDateTime startTime = task.getStartTime();
                    LocalDateTime endTime = task.getEndTime();
                    Duration duration = Duration.between(startTime, endTime);
                    fromUnit = "seconds";
                    resourceUsageValue = Double.parseDouble(String.valueOf(duration.toSeconds()));
                }
                double resourceConsumptionValue = Double.parseDouble(resource.getFuelPerUse());
                resourceUsageValue = TimeUnitConverter.convert(fromUnit, toUnit, resourceUsageValue);
                double fuelAmountConsumed = resourceUsageValue * resourceConsumptionValue;

                IntermediateProcessConsumption intermediateProcessConsumption = new IntermediateProcessConsumption();
                intermediateProcessConsumption.setTask(map.get("taskName").toString());
                intermediateProcessConsumption.setProcess(process);
                intermediateProcessConsumption.setUnit(resource.getFuelUnit());
                intermediateProcessConsumption.setValue(fuelAmountConsumed);
                intermediateProcessConsumption.setFuelType(resource.getFuelType());
                intermediateProcessConsumptionRepository.save(intermediateProcessConsumption);
                intermediateProcessConsumptionList.add(intermediateProcessConsumption);
            }

        }
        return intermediateProcessConsumptionList;

    }

    @Transactional
    public double calculateEmissions(List<IntermediateProcessConsumption> list) {
        double co2EmissionAmount = 0.0;
        for (IntermediateProcessConsumption consumption : list) {
            FuelEmissionFactor factor = fuelEmissionFactorRepository.findByFuelType(consumption.getFuelType());
            co2EmissionAmount += factor.calculateEmissionAmount(consumption.getValue(), consumption.getUnit());
        }
        IntermediateCo2Emission intermediateCo2Emission = new IntermediateCo2Emission();
        intermediateCo2Emission.setProcess(list.get(0).getProcess());
        intermediateCo2Emission.setValue(co2EmissionAmount);
        intermediateCo2Emission.setTask(list.get(0).getTask());
        intermediateCo2EmissionRepository.save(intermediateCo2Emission);
        return co2EmissionAmount;

    }
    @Transactional
    public double calculateTotalEmissions(Process process) {
        System.out.println(process);
        List<IntermediateCo2Emission> intermediateCo2EmissionList = intermediateCo2EmissionRepository.findAllByProcess(process);
        double sumCo2Emissions = 0.0;
        for (IntermediateCo2Emission i : intermediateCo2EmissionList) {
            sumCo2Emissions += i.getValue();
        }
        IntermediateCo2Emission intermediateCo2Emission = new IntermediateCo2Emission();
        intermediateCo2Emission.setProcess(process);
        intermediateCo2Emission.setValue(sumCo2Emissions);
        intermediateCo2Emission.setTask("total");
        intermediateCo2EmissionRepository.save(intermediateCo2Emission);
        Map payload = new HashMap();
        payload.put("processName", process.getProcessName());
        payload.put("processInstance", process.getProcessKey());
        payload.put("taskName", "Total");
        payload.put("co2EmissionValue", sumCo2Emissions);
        payload.put("diagramXML", process.getDiagramXML());
        try {
            webSocketService.sendPayloadToFrontend(payload);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sumCo2Emissions;


    }

}
