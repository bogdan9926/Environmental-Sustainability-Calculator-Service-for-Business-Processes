import React from 'react';
import './processTable.css';

const ProcessTable = ({ tasks }) => {
    return (
        <table className="process-table">
            <thead>
            <tr>
                <th>Task Name</th>
                <th>CO2 Emission Value</th>
                <th>Process Name</th>
                <th>Process Instance</th>
            </tr>
            </thead>
            <tbody>
            {tasks.map((task, index) => (
                <tr key={index}>
                    <td>{task.taskName}</td>
                    <td>{task.co2EmissionValue} kg</td>
                    <td>{task.processName}</td>
                    <td>{task.processInstance}</td>
                </tr>
            ))}
            </tbody>
        </table>
    );
};

export default ProcessTable;
