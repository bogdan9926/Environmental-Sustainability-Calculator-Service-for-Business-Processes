import React, { useState } from 'react';
import Modal from 'react-modal';
import AceEditor from 'react-ace';
import 'ace-builds/src-noconflict/mode-json';
import 'ace-builds/src-noconflict/mode-javascript';
import 'ace-builds/src-noconflict/theme-github';
import './fileUpload.css';

Modal.setAppElement('#root'); // Set the root element for accessibility

const AnnotationsUploadComponent = ({ onSubmit }) => {
    const [modalIsOpen, setIsOpen] = useState(false);
    const [jsonText, setJsonText] = useState(`{
    "name": "Process_1y80xt6",
    "frequencyPerMonth": 5,
    "tasks": [
      {
        "name": "activity3",
        "duration": "30",
        "timeUnit": "minutes",
        "resourcesUsed": [
          {"resourceName": "Welder", "timeUsed": "30", "unit": "minutes"}
        ]
      },
      {
        "name": "plmda",
        "duration": "45",
        "timeUnit": "minutes",
        "resourcesUsed": [
          {"resourceName": "Paint Sprayer", "timeUsed": "30", "unit": "minutes"}
        ]
      }
    ],
    "resources": [
      {"name": "Welder", "type": "atomic", "fuelPerUse": "500", "fuelType": "Diesel", "fuelUnit": "Wh", "timeUnit": "hour"},
      {"name": "Paint Sprayer", "type": "atomic", "fuelPerUse": "300","fuelType": "Diesel", "fuelUnit": "Wh", "timeUnit": "hour"}
    ]
  }`);

    const openModal = () => setIsOpen(true);
    const closeModal = () => setIsOpen(false);

    const handleFileUpload = (event) => {
        const file = event.target.files[0];
        const reader = new FileReader();
        reader.onload = () => {
            setJsonText(reader.result);
        }
        reader.readAsText(file);
    };

    const handleSubmit = () => {
        onSubmit(jsonText);
        closeModal();
    };

    return (
        <div className="file-upload-component">
            <button className="upload-button" onClick={openModal}>Upload File Annotations Here</button>
            <Modal className="modal" isOpen={modalIsOpen} onRequestClose={closeModal}>
                <h2 className="modal-title">Upload Annotations or Write Here</h2>
                <AceEditor
                    mode="json"
                    theme="github"
                    value={jsonText}
                    onChange={(value) => setJsonText(value)}
                    name="json-editor"
                    editorProps={{ $blockScrolling: true }}
                    width="100%"
                    height="400px"
                    wrapEnabled={true}
                    setOptions={{
                        useWorker: false, // Disable worker to avoid a warning in console
                    }}
                />
                <br />
                <input className="file-input" type="file" onChange={handleFileUpload} />
                <br />
                <button className="submit-button" onClick={handleSubmit}>Submit</button>
                <button className="close-button" onClick={closeModal}>Close</button>
            </Modal>
        </div>
    );
};

export default AnnotationsUploadComponent;
