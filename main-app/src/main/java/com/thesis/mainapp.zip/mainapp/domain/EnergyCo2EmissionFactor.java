package com.thesis.mainapp.domain;

import java.math.BigDecimal;
import jakarta.persistence.*;


@Entity
@Table(name = "energy_co2_emission_factor")
public class EnergyCo2EmissionFactor {
    public static final String KWH = "KWH";
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "country", nullable = false, length = 255)
    private String country;

    @Column(name = "unit", nullable = false, length = 255)
    private String unit;

    @Column(name = "factor", nullable = false, precision = 10, scale = 4)
    private BigDecimal factor;

    // Constructors
    public EnergyCo2EmissionFactor() {
    }

    // Getter and Setter methods
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public BigDecimal getCo2Factor() {
        return factor;
    }

    public void setCo2Factor(BigDecimal co2Factor) {
        this.factor = co2Factor;
    }

    // Optionally override toString, equals, and hashCode methods
}
