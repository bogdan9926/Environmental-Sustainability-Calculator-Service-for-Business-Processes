package com.thesis.mainapp.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.thesis.mainapp.config.repositories.AnnotationJsonRepository;
import com.thesis.mainapp.config.repositories.FrontendDataRepository;
import com.thesis.mainapp.config.repositories.FuelEmissionFactorRepository;
import com.thesis.mainapp.domain.FrontendData;
import com.thesis.mainapp.domain.FuelEmissionFactor;
import com.thesis.mainapp.domain.annotations.AnnotationJson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
public class WebSocketService {

    @Autowired
    private SimpMessagingTemplate messagingTemplate;
    @Autowired
    private FrontendDataRepository frontendDataRepository;
    @Autowired
    private AnnotationJsonRepository annotationJsonRepository;
    @Autowired
    private FuelEmissionFactorRepository fuelEmissionFactorRepository;

    public void sendMessage(String message) {
        messagingTemplate.convertAndSend("/topic/messages", message);
    }

    public void sendAnnotations(List<AnnotationJson> message) {
        messagingTemplate.convertAndSend("/topic/annotations", message);
    }
    public void sendFuelEmissions(List<FuelEmissionFactor> message) {
        messagingTemplate.convertAndSend("/topic/fuelEmissions", message);
    }
    @Transactional
    public void sendPayloadToFrontend(Map payload) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        sendMessage(objectMapper.writeValueAsString(payload));
        //send emission per task to front
        FrontendData frontendData = objectMapper.readValue(objectMapper.writeValueAsString(payload), FrontendData.class);
        frontendDataRepository.save(frontendData);
    }
    public void sendAllAnnotationJsonToFrontend() {
        List<AnnotationJson> annotationJsonList=annotationJsonRepository.findAll();
        sendAnnotations(annotationJsonList);
    }
    public void sendAllFuelEmissionFactorToFrontend() {
        List<FuelEmissionFactor> fuelEmissionFactors = fuelEmissionFactorRepository.findAll();
        sendFuelEmissions(fuelEmissionFactors);
    }
}
