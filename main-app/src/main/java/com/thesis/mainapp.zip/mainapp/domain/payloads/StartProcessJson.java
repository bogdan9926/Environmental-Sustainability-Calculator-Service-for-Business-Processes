package com.thesis.mainapp.domain.payloads;

public class StartProcessJson{
    private String processId;
    private String containerId;
    public String getProcessId() {
        return processId;
    }

    public void setProcessId(String processId) {
        this.processId = processId;
    }

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }
}
