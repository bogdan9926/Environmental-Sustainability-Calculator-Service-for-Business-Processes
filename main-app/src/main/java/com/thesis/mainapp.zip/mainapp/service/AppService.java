package com.thesis.mainapp.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.thesis.mainapp.config.repositories.*;
import com.thesis.mainapp.domain.FrontendData;
import com.thesis.mainapp.domain.FuelEmissionFactor;
import com.thesis.mainapp.domain.Process;
import com.thesis.mainapp.domain.Task;
import com.thesis.mainapp.domain.annotations.AnnotationJson;
import com.thesis.mainapp.domain.annotations.ProcessAnnotation;
import com.thesis.mainapp.domain.annotations.TaskAnnotation;
import com.thesis.mainapp.domain.intermediate.IntermediateProcessConsumption;
import com.thesis.mainapp.domain.payloads.*;
import netscape.javascript.JSObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class AppService {

    //    @Value("${jbpm.containerName}")
    private String containerName;

    //    @Value("${jbpm.containerId}")
    private String containerId;

    @Value("${jbpm.artifactId}")
    private String artifactId;

    @Value("com.thesis")
    private String groupId;

    @Value("${shared.directory}")
    private String location;


    @Value("${jbpm.version}")
    private String version;

    @Autowired
    private RabbitService rabbitService;

    @Autowired
    private EmissionFactorService emissionFactorService;

    @Autowired
    private ProcessRepository processRepository;
    @Autowired
    private ProcessAnnotationRepository processAnnotationRepository;
    @Autowired
    private FrontendDataRepository frontendDataRepository;
    @Autowired
    private WebSocketService webSocketService;
    @Autowired
    private HelperService helperService;
    @Autowired
    private TaskRepository taskRepository;
    @Autowired
    private FuelEmissionFactorRepository fuelEmissionFactorRepository;

    public String uploadDiagram(DiagramUploadRequest diagramUploadRequest) throws IOException, InterruptedException {
        MultipartFile diagram = diagramUploadRequest.getDiagram();
        String message = transferFile(diagram);
        String channelName = "";
        String returnString = "";
        switch (diagramUploadRequest.getPlatform()) {
            case ("camunda"): {
                message = addCamundaConfiguration(diagramUploadRequest, message);
                channelName = "camundaChannel";
                break;
            }
            case ("jbpm"): {
                Random random = new Random();
                Integer randomInt = random.nextInt();
                containerId = randomInt.toString();
                containerName = randomInt.toString();
                message = addJbpmConfiguration(diagramUploadRequest, message);

                saveDiagramToKjar(diagram);
                channelName = "jbpmChannel";
                returnString = containerId;
                break;
            }
//            case ("activiti"): {
//                message = addActivitiConfiguration(diagramUploadRequest, message);
//                channelName = "activitiChannel";
//                break;
//            }
        }

        rabbitService.sendMessage(channelName, message);

        return returnString;
    }

    public String addCamundaConfiguration(DiagramUploadRequest diagramUploadRequest, String destinationPath) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        DeployDiagramJson json = new DeployDiagramJson();

        json.setFileLocation(destinationPath);
        json.setProcessId(diagramUploadRequest.getProcessId());
        return objectMapper.writeValueAsString(json);

    }

    public String addJbpmConfiguration(DiagramUploadRequest diagramUploadRequest, String destinationPath) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        JbpmJson json = new JbpmJson();

        json.setFileLocation(destinationPath);
        json.setProcessId(diagramUploadRequest.getProcessId());
        json.setArtifactId(artifactId);
        json.setContainerId(containerId);
        json.setContainerName(containerName);
        json.setGroupId(groupId);
        json.setVersion(version);

        return objectMapper.writeValueAsString(json);
    }

    public String transferFile(MultipartFile diagram) throws IOException {
        Path filePath = Paths.get(location, diagram.getOriginalFilename());
        File file = filePath.toFile();
        try (FileOutputStream fos = new FileOutputStream(file)) {
            fos.write(diagram.getBytes());
        }
        return filePath.toString();
    }

    public void saveDiagramToKjar(MultipartFile diagram) {
        String kjarPath = "/home/bogdan/thesis/01-tutorial-first-business-application/business-application-kjar/src/main/resources/";
        String fileName = diagram.getOriginalFilename();

        try {
            Path path = Paths.get(kjarPath + fileName);
            Files.copy(diagram.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("File uploaded successfully: " + fileName);
        } catch (Exception e) {
            System.out.println("File upload failed: " + fileName);
        }
    }

//    public String addActivitiConfiguration(DiagramUploadRequest diagramUploadRequest, String destinationPath) throws JsonProcessingException {
//        ObjectMapper objectMapper = new ObjectMapper();
//        ActivitiJson json = new ActivitiJson();
//        json.setFileLocation(destinationPath);
//        json.setProcessName(diagramUploadRequest.getProcessName());
//        return objectMapper.writeValueAsString(json);
//    }

    public void startProcess(ProcessStartRequest processStartRequest) throws IOException, InterruptedException {
        String channelName = "";
        ObjectMapper objectMapper = new ObjectMapper();

        StartProcessJson startProcessJson = new StartProcessJson();
        startProcessJson.setProcessId(processStartRequest.getProcessId());
        switch (processStartRequest.getPlatform()) {
            case ("camunda"): {
                channelName = "camundaChannel";
                break;
            }
            case ("jbpm"): {
                startProcessJson.setContainerId(processStartRequest.getContainerId());
                channelName = "jbpmChannel";
                break;
            }
        }

        rabbitService.sendMessage(channelName, objectMapper.writeValueAsString(startProcessJson));

    }

    // MESSAGE SHOULD CONTAIN processName, processKey, taskName, startTime,endTime, platform
    @Transactional
    public void parseReceivedMessage(String message) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            Map map = mapper.readValue(message, Map.class);
            System.out.println(map);
            if (map.containsKey("taskName") && !Objects.equals(map.get("taskName").toString(), "null")) {
                System.out.println("taskName");
                if(map.containsKey("startTime")) {
                    LocalDateTime startDateTime;
                    if(map.get("platform")=="camunda") {
                        ArrayList<Integer> startArray = (ArrayList) map.get("startTime");
                        startDateTime = LocalDateTime.of(startArray.get(0), startArray.get(1), startArray.get(2), startArray.get(3), startArray.get(4), startArray.get(5), startArray.get(6));
                        map.put("startTime", startDateTime);
                    } else {
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSS");
                        startDateTime = LocalDateTime.parse(map.get("startTime").toString(), formatter);
                    }

                    Task task = new Task();
                    task.setName(map.get("taskName").toString());
                    task.setStartTime(startDateTime);
                    task.setProcess(processRepository.findByProcessNameAndProcessKey(map.get("processName").toString(), map.get("processKey").toString()));
                    taskRepository.save(task);
                } else if (map.containsKey("endTime")) {
                    LocalDateTime endDateTime;
                    if(map.get("platform")=="camunda") {
                        ArrayList<Integer> startArray = (ArrayList) map.get("endTime");
                        endDateTime = LocalDateTime.of(startArray.get(0), startArray.get(1), startArray.get(2), startArray.get(3), startArray.get(4), startArray.get(5), startArray.get(6));
                        map.put("endTime", endDateTime);
                    } else {
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSS");
                        endDateTime = LocalDateTime.parse(map.get("endTime").toString(), formatter);
                    }
                    Task task = taskRepository.findByNameAndProcess(map.get("taskName").toString(),processRepository.findByProcessNameAndProcessKey(map.get("processName").toString(), map.get("processKey").toString()));
                    task.setEndTime(endDateTime);
                    taskRepository.save(task);

                    parseReceivedMessageTaskName(map);

                }
            } else if ((map.containsKey("status") && map.get("status").toString().equals("1"))) {
                System.out.println("status 1");
                Process process = new Process();
                process.setStartTime(LocalDateTime.now());
//                process.setPlatform(Process.PLATFORM_JBPM);
                process.setProcessName(map.get("processName").toString());
                process.setProcessKey(map.get("processKey").toString());
                process.setStatus(map.get("status").toString());
                process.setDiagramXML(map.get("diagramXML").toString());
                processRepository.save(process);
            } else if (map.containsKey("status") && Objects.equals(map.get("status").toString(), "2")) {
                System.out.println("status 2");
                System.out.println(map.get("processName").toString());
                System.out.println(map.get("processKey").toString());
                Process process = processRepository.findByProcessNameAndProcessKey(map.get("processName").toString(), map.get("processKey").toString());
                process.setEndTime(LocalDateTime.now());
                process.setStatus(map.get("status").toString());
                processRepository.save(process);
                calculateTotalEmissions(process);
            }

        } catch (IOException e) {
            e.printStackTrace();
//        }
        }
    }


    public void parseReceivedMessageTaskName(Map map) throws JsonProcessingException {
        Optional<ProcessAnnotation> optionalProcessAnnotation = processAnnotationRepository.findByName(map.get("processName").toString());
        System.out.println(map);
        if(optionalProcessAnnotation.isPresent()) {
            ProcessAnnotation processAnnotation = optionalProcessAnnotation.get();
            Optional<TaskAnnotation> optionalTaskAnnotation = processAnnotation.getTask(map.get("taskName").toString());
            if (optionalTaskAnnotation.isPresent()) {
                TaskAnnotation taskAnnotation = optionalTaskAnnotation.get();
                List<IntermediateProcessConsumption> intermediateProcessConsumptionList = emissionFactorService.calculateConsumption(map, taskAnnotation);
                double co2EmissionFactor = emissionFactorService.calculateEmissions(intermediateProcessConsumptionList);
                Map payload = new HashMap();
                payload.put("processName", intermediateProcessConsumptionList.get(0).getProcess().getProcessName());
                payload.put("processInstance",intermediateProcessConsumptionList.get(0).getProcess().getProcessKey());
                payload.put("taskName",taskAnnotation.getName());
                payload.put("co2EmissionValue", co2EmissionFactor);
//                payload.put("diagramBytes", intermediateProcessConsumptionList.get(0).getProcess().getDiagram());
                payload.put("diagramXML", intermediateProcessConsumptionList.get(0).getProcess().getDiagramXML());
                webSocketService.sendPayloadToFrontend(payload);
            }
        }


    }
    public void calculateTotalEmissions(Process process) {
        double co2EmissionFactor = emissionFactorService.calculateTotalEmissions(process);
    }
    @Transactional
    public void saveAnnotations(String json) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        ProcessAnnotation processAnnotation = mapper.readValue(json, ProcessAnnotation.class);
        String processName = processAnnotation.getName();
        try {
            helperService.saveOrUpdate(processAnnotation);
            helperService.saveAnnotationBody(json, processName);
            webSocketService.sendAllAnnotationJsonToFrontend();
        } catch (Exception e) {
            // Log the exception and rethrow it to trigger rollback
            e.printStackTrace();
            throw e;
        }
    }
    @Transactional
    public void saveFactors(String json) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        List<FuelEmissionFactor> fuelEmissionFactors = mapper.readValue(json, new TypeReference<List<FuelEmissionFactor>>() { });
        try {
            fuelEmissionFactorRepository.saveAll(fuelEmissionFactors);
            webSocketService.sendAllFuelEmissionFactorToFrontend();
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

}
